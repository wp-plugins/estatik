<li id="period_<?php echo $id?>">
    <label><?php echo $es_period_title?></label>
    <small onclick="es_period_delete(this)"></small>
    <span class="es_field_loader es_period_loader"></span>
    <input type="hidden" value="<?php echo $id?>" name="es_period_id" class="es_period_id" />
</li>
 