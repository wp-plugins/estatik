<li id="currency_<?php echo $id?>">
    <label> <?php echo $es_currency_title?></label>
    <small onclick="es_currency_delete(this)"></small>
    <span class="es_field_loader es_currency_loader"></span>
    <input type="hidden" value="<?php echo $id?>" name="es_currency_id" class="es_currency_id" />
</li>